# QBX

**QBX is an experimental goal-driven adaptive archive format.**

Instead of treating an archive as only a stream of compressed files, QBX
experiments with content-defined blocks, global deduplication, adaptive
representations and optimization-based archive planning.

## QBX 1.0 Technology Preview

Current pipeline:

Data
→ Content-defined chunking
→ SHA-256 content addressing
→ Global deduplication
→ Adaptive representation selection
→ QBX container
→ Verified lossless reconstruction

QBX also contains an experimental quantum planning pipeline:

Archive planning problem
→ QUBO
→ Quantum circuit
→ Measurement
→ Candidate archive strategy

## Current codecs

- RAW
- ZLIB
- LZMA

## Usage

Pack:

    python qbx_cli.py pack PATH archive.qbx

Unpack:

    python qbx_cli.py unpack archive.qbx OUTPUT

Run tests:

    python -m pytest -q

Run quantum experiment:

    PYTHONPATH=. python -m experiments.quantum_planner_v1

## Verified experiment

The first research experiment used:

- 9 qubits
- 4096 shots
- Qiskit Aer simulator
- exact classical optimum: 155
- best sampled solution: 155

The experiment recovered the known optimum.

This is evidence that the complete experimental pipeline executes correctly.
It is NOT evidence of quantum advantage.

## Status

Research technology preview. Do not use QBX as the only copy of important data.

## License

See LICENSE.
