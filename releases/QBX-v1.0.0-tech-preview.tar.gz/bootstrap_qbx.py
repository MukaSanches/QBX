from pathlib import Path

FILES = {
"qbx/core.py": r'''
from __future__ import annotations
import hashlib, json, lzma, os, struct, time, zlib
from dataclasses import dataclass
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

MAGIC = b"QBX\x01"
FORMAT_VERSION = 1

MIN_CHUNK = 32 * 1024
TARGET_CHUNK = 128 * 1024
MAX_CHUNK = 512 * 1024
MASK = TARGET_CHUNK - 1

def digest(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()

def hexdigest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def chunks(data: bytes):
    """Fast experimental content-defined chunking."""
    if not data:
        return
    start = 0
    fp = 0
    for i, b in enumerate(data):
        fp = ((fp << 1) ^ b ^ (fp >> 31)) & 0xffffffff
        n = i - start + 1
        if n >= MIN_CHUNK and ((fp & MASK) == 0 or n >= MAX_CHUNK):
            yield data[start:i+1]
            start = i + 1
            fp = 0
    if start < len(data):
        yield data[start:]

def entropy_sample(data: bytes) -> float:
    if not data: return 0.0
    sample = data if len(data) <= 16384 else data[::max(1,len(data)//16384)]
    counts = [0]*256
    for b in sample: counts[b] += 1
    import math
    n = len(sample)
    return -sum((c/n)*math.log2(c/n) for c in counts if c)

def candidates(data: bytes):
    # Skip expensive compression for near-random/already-compressed material.
    e = entropy_sample(data)
    out = [("raw", data)]
    if e < 7.98:
        out.append(("zlib", zlib.compress(data, 9)))
        out.append(("lzma", lzma.compress(data, preset=6)))
    return out

def choose(data: bytes):
    opts = candidates(data)
    # v1 objective: bytes first. Planner will generalize this.
    return min(opts, key=lambda x: len(x[1]))

def decode(codec: str, payload: bytes) -> bytes:
    if codec == "raw": return payload
    if codec == "zlib": return zlib.decompress(payload)
    if codec == "lzma": return lzma.decompress(payload)
    raise ValueError("Unsupported codec: " + codec)

@dataclass
class Block:
    codec: str
    usize: int
    payload: bytes

def pack(source: str, output: str):
    t0 = time.perf_counter()
    src = Path(source)
    root = src.parent if src.is_file() else src
    files = [src] if src.is_file() else sorted(p for p in src.rglob("*") if p.is_file())

    unique: dict[str, bytes] = {}
    entries = []
    original = 0
    logical_chunks = 0

    for p in files:
        data = p.read_bytes()
        original += len(data)
        ids = []
        for ch in chunks(data):
            logical_chunks += 1
            h = hexdigest(ch)
            ids.append(h)
            unique.setdefault(h, ch)
        entries.append({
            "path": str(p.relative_to(root)).replace("\\","/"),
            "size": len(data),
            "sha256": hexdigest(data),
            "blocks": ids
        })

    def work(item):
        h, data = item
        codec, payload = choose(data)
        return h, Block(codec, len(data), payload)

    workers = max(1, min(8, os.cpu_count() or 1))
    with ThreadPoolExecutor(max_workers=workers) as ex:
        encoded = dict(ex.map(work, unique.items()))

    manifest = {
        "format":"QBX",
        "version":FORMAT_VERSION,
        "features":[
            "content-defined-chunking",
            "global-deduplication",
            "adaptive-codec-selection",
            "sha256-integrity",
            "random-block-addressing"
        ],
        "files":entries
    }
    m = json.dumps(manifest, separators=(",",":"), ensure_ascii=False).encode()

    with open(output, "wb") as f:
        f.write(MAGIC)
        f.write(struct.pack(">Q", len(m)))
        f.write(m)
        f.write(struct.pack(">Q", len(encoded)))
        for h, block in encoded.items():
            cb = block.codec.encode()
            f.write(bytes.fromhex(h))
            f.write(struct.pack("B", len(cb)))
            f.write(cb)
            f.write(struct.pack(">QQ", block.usize, len(block.payload)))
            f.write(block.payload)

    size = os.path.getsize(output)
    elapsed = time.perf_counter()-t0
    dedup_saved = logical_chunks-len(unique)
    return {
        "files":len(files),
        "original":original,
        "archive":size,
        "ratio":size/original if original else 0,
        "logical_chunks":logical_chunks,
        "unique_chunks":len(unique),
        "deduplicated_chunks":dedup_saved,
        "seconds":elapsed
    }

def unpack(archive: str, destination: str):
    t0 = time.perf_counter()
    with open(archive,"rb") as f:
        if f.read(4) != MAGIC: raise ValueError("Invalid QBX magic")
        mlen = struct.unpack(">Q",f.read(8))[0]
        manifest = json.loads(f.read(mlen))
        count = struct.unpack(">Q",f.read(8))[0]
        blocks={}
        for _ in range(count):
            h=f.read(32).hex()
            clen=struct.unpack("B",f.read(1))[0]
            codec=f.read(clen).decode()
            usize,csize=struct.unpack(">QQ",f.read(16))
            raw=decode(codec,f.read(csize))
            if len(raw)!=usize or hexdigest(raw)!=h:
                raise ValueError("QBX integrity failure")
            blocks[h]=raw

    dst=Path(destination)
    for e in manifest["files"]:
        target=dst/e["path"]
        target.parent.mkdir(parents=True,exist_ok=True)
        data=b"".join(blocks[h] for h in e["blocks"])
        if len(data)!=e["size"] or hexdigest(data)!=e["sha256"]:
            raise ValueError("File reconstruction failure: "+e["path"])
        target.write_bytes(data)

    return {"files":len(manifest["files"]), "seconds":time.perf_counter()-t0}
''',

"qbx/planner.py": r'''
from dataclasses import dataclass

@dataclass(frozen=True)
class Strategy:
    name: str
    size: int
    decode_ms: float
    memory_mb: float

def objective(s: Strategy, size_weight=1.0, time_weight=0.0, memory_weight=0.0):
    return (
        size_weight*s.size +
        time_weight*s.decode_ms +
        memory_weight*s.memory_mb
    )

def classical_plan(groups, max_decode_ms=None, max_memory_mb=None):
    """
    Baseline solver. Each group contains alternative representations.
    This becomes the reference against which QUBO/QAOA is measured.
    """
    result=[]
    for group in groups:
        valid=[
            s for s in group
            if (max_decode_ms is None or s.decode_ms <= max_decode_ms)
            and (max_memory_mb is None or s.memory_mb <= max_memory_mb)
        ]
        if not valid:
            raise ValueError("No feasible strategy")
        result.append(min(valid,key=objective))
    return result
''',

"qbx/quantum/qubo.py": r'''
"""
QBX Quantum Archive Planner.

Maps representation-selection into a QUBO-style objective.
One-hot constraint:
    exactly one representation must be selected per block group.

This module intentionally keeps the mathematical model independent
from any particular quantum provider.
"""

def build_qubo(cost_groups, penalty=None):
    if penalty is None:
        penalty = max(
            (abs(c) for g in cost_groups for c in g),
            default=1.0
        ) * 10 + 1

    Q={}
    names=[]
    for g, costs in enumerate(cost_groups):
        vars=[]
        for j,cost in enumerate(costs):
            v=f"x_{g}_{j}"
            vars.append(v)
            names.append(v)
            # cost + penalty*(sum x - 1)^2
            Q[(v,v)] = Q.get((v,v),0.0) + float(cost) - penalty

        for i in range(len(vars)):
            for j in range(i+1,len(vars)):
                a,b=vars[i],vars[j]
                Q[(a,b)] = Q.get((a,b),0.0) + 2*penalty

    constant=penalty*len(cost_groups)
    return Q, constant, names
''',

"qbx_cli.py": r'''
import argparse, json
from qbx.core import pack, unpack

p=argparse.ArgumentParser(prog="qbx")
s=p.add_subparsers(dest="cmd",required=True)

a=s.add_parser("pack")
a.add_argument("source")
a.add_argument("output")

a=s.add_parser("unpack")
a.add_argument("archive")
a.add_argument("destination")

args=p.parse_args()

if args.cmd=="pack":
    print(json.dumps(pack(args.source,args.output),indent=2))
else:
    print(json.dumps(unpack(args.archive,args.destination),indent=2))
''',

"tests/test_qbx.py": r'''
from pathlib import Path
from qbx.core import pack, unpack, hexdigest

def test_roundtrip(tmp_path):
    src=tmp_path/"src"
    src.mkdir()
    data=(b"QBX"*100000)+(b"A"*200000)
    (src/"a.bin").write_bytes(data)
    (src/"b.bin").write_bytes(data)
    archive=tmp_path/"x.qbx"
    dst=tmp_path/"dst"

    stats=pack(str(src),str(archive))
    unpack(str(archive),str(dst))

    assert hexdigest((src/"a.bin").read_bytes()) == hexdigest((dst/"a.bin").read_bytes())
    assert hexdigest((src/"b.bin").read_bytes()) == hexdigest((dst/"b.bin").read_bytes())
    assert stats["deduplicated_chunks"] > 0
''',

"docs/QBX-SPEC-1.0.md": r'''
# QBX Format — Research Specification 1.0

QBX is an experimental lossless adaptive archive container.

## Current principles

1. Content-defined chunking.
2. Global content-addressed deduplication.
3. Independent representation per unique chunk.
4. Adaptive codec selection.
5. Cryptographic integrity verification.
6. Deterministic reconstruction.
7. Quantum/classical planning kept separate from byte encoding.
8. No claim of quantum advantage without reproducible benchmarks.

## Container

Magic:
`51 42 58 01`

Followed by:
- manifest length;
- UTF-8 JSON manifest;
- unique block count;
- content-addressed block records.

Every reconstructed file must match its original SHA-256.
''',

"README.md": r'''
# QBX

Experimental adaptive archive technology.

QBX investigates a different archive architecture based on:

- content-defined chunking
- global deduplication
- adaptive representations
- integrity verification
- classical optimization
- QUBO/quantum optimization research

The quantum optimizer does not "quantum-compress bytes".
It investigates the combinatorial representation-planning problem.

Status: research implementation. No quantum-advantage claim.
'''
}

for name, content in FILES.items():
    p=Path(name)
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(content.lstrip(),encoding="utf-8")

Path("qbx/__init__.py").touch()
Path("qbx/quantum/__init__.py").touch()

print("QBX Research Build generated.")
